// DeepSeek API 配置
const API_BASE_URL = 'https://api.deepseek.com/v1';
let API_KEY = 'sk-c1417a5dcd404ab4904982e9b3a44f87';
let conversationHistory = [];

// DOM 元素
const chatContainer = document.getElementById('chatContainer');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const settingsBtn = document.getElementById('settingsBtn');
const clearBtn = document.getElementById('clearBtn');
const settingsPanel = document.getElementById('settingsPanel');
const closeSettings = document.getElementById('closeSettings');
const saveSettings = document.getElementById('saveSettings');
const statusIndicator = document.getElementById('statusIndicator');

// 设置相关元素
const apiKeyInput = document.getElementById('apiKey');
const temperatureInput = document.getElementById('temperature');
const temperatureValue = document.getElementById('temperatureValue');
const maxTokensInput = document.getElementById('maxTokens');
const streamModeCheckbox = document.getElementById('streamMode');

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    setupEventListeners();
    autoResizeTextarea();
});

// 设置事件监听器
function setupEventListeners() {
    // 发送消息
    sendBtn.addEventListener('click', handleSendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    });

    // 设置面板
    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.remove('hidden');
    });

    closeSettings.addEventListener('click', () => {
        settingsPanel.classList.add('hidden');
    });

    saveSettings.addEventListener('click', handleSaveSettings);

    // 清空对话
    clearBtn.addEventListener('click', handleClearChat);

    // 温度值显示
    temperatureInput.addEventListener('input', (e) => {
        temperatureValue.textContent = e.target.value;
    });

    // 快捷提示
    document.querySelectorAll('.chip').forEach(chip => {
        chip.addEventListener('click', (e) => {
            const prompt = e.target.dataset.prompt;
            userInput.value = prompt;
            handleSendMessage();
        });
    });

    // 自动调整输入框高度
    userInput.addEventListener('input', autoResizeTextarea);
}

// 自动调整文本框高度
function autoResizeTextarea() {
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 150) + 'px';
}

// 加载设置
function loadSettings() {
    const savedSettings = localStorage.getItem('deepseekSettings');
    if (savedSettings) {
        const settings = JSON.parse(savedSettings);
        API_KEY = settings.apiKey || API_KEY;
        apiKeyInput.value = API_KEY;
        temperatureInput.value = settings.temperature || 1.0;
        temperatureValue.textContent = settings.temperature || 1.0;
        maxTokensInput.value = settings.maxTokens || 2000;
        streamModeCheckbox.checked = settings.streamMode !== false;
    }

    // 加载对话历史
    const savedHistory = localStorage.getItem('conversationHistory');
    if (savedHistory) {
        conversationHistory = JSON.parse(savedHistory);
        restoreChatHistory();
    }
}

// 保存设置
function handleSaveSettings() {
    const settings = {
        apiKey: apiKeyInput.value,
        temperature: parseFloat(temperatureInput.value),
        maxTokens: parseInt(maxTokensInput.value),
        streamMode: streamModeCheckbox.checked
    };

    API_KEY = settings.apiKey;
    localStorage.setItem('deepseekSettings', JSON.stringify(settings));
    
    settingsPanel.classList.add('hidden');
    showToast('设置已保存', 'success');
}

// 恢复聊天历史
function restoreChatHistory() {
    const welcomeMessage = document.querySelector('.welcome-message');
    if (welcomeMessage) {
        welcomeMessage.remove();
    }

    conversationHistory.forEach(msg => {
        appendMessage(msg.role, msg.content, false);
    });
}

// 保存对话历史
function saveConversationHistory() {
    localStorage.setItem('conversationHistory', JSON.stringify(conversationHistory));
}

// 发送消息
async function handleSendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    if (!API_KEY || API_KEY === 'your_deepseek_api_key_here') {
        showToast('请先在设置中配置 API Key', 'error');
        settingsPanel.classList.remove('hidden');
        return;
    }

    // 清空输入框
    userInput.value = '';
    autoResizeTextarea();

    // 移除欢迎消息
    const welcomeMessage = document.querySelector('.welcome-message');
    if (welcomeMessage) {
        welcomeMessage.remove();
    }

    // 添加用户消息
    appendMessage('user', message);
    conversationHistory.push({ role: 'user', content: message });
    saveConversationHistory();

    // 禁用发送按钮
    sendBtn.disabled = true;
    setStatus('正在思考...', 'thinking');

    // 调用 API
    const settings = JSON.parse(localStorage.getItem('deepseekSettings') || '{}');
    const useStream = settings.streamMode !== false;

    if (useStream) {
        await callDeepSeekStreaming(conversationHistory);
    } else {
        await callDeepSeekAPI(conversationHistory);
    }

    // 启用发送按钮
    sendBtn.disabled = false;
    setStatus('就绪', 'ready');
}

// 调用 DeepSeek API (非流式)
async function callDeepSeekAPI(messages) {
    const settings = JSON.parse(localStorage.getItem('deepseekSettings') || '{}');

    try {
        const response = await fetch(`${API_BASE_URL}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: 'deepseek-chat',
                messages: messages,
                temperature: settings.temperature || 1.0,
                max_tokens: settings.maxTokens || 2000,
                stream: false
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || '请求失败');
        }

        const data = await response.json();
        const assistantMessage = data.choices[0].message.content;

        appendMessage('assistant', assistantMessage);
        conversationHistory.push({ role: 'assistant', content: assistantMessage });
        saveConversationHistory();

    } catch (error) {
        console.error('API 调用失败:', error);
        showToast(`错误: ${error.message}`, 'error');
        appendMessage('assistant', '抱歉，我遇到了一些问题。请检查你的 API Key 和网络连接。');
    }
}

// 调用 DeepSeek API (流式)
async function callDeepSeekStreaming(messages) {
    const settings = JSON.parse(localStorage.getItem('deepseekSettings') || '{}');
    let assistantMessage = '';
    let messageElement = null;

    try {
        const response = await fetch(`${API_BASE_URL}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: 'deepseek-chat',
                messages: messages,
                temperature: settings.temperature || 1.0,
                max_tokens: settings.maxTokens || 2000,
                stream: true
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || '请求失败');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        // 创建消息元素
        messageElement = appendMessage('assistant', '', true);

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    if (data === '[DONE]') continue;

                    try {
                        const json = JSON.parse(data);
                        const delta = json.choices[0]?.delta?.content;
                        if (delta) {
                            assistantMessage += delta;
                            updateMessageContent(messageElement, assistantMessage);
                        }
                    } catch (e) {
                        // 忽略解析错误
                    }
                }
            }
        }

        conversationHistory.push({ role: 'assistant', content: assistantMessage });
        saveConversationHistory();

    } catch (error) {
        console.error('API 调用失败:', error);
        showToast(`错误: ${error.message}`, 'error');
        if (messageElement) {
            updateMessageContent(messageElement, '抱歉，我遇到了一些问题。请检查你的 API Key 和网络连接。');
        } else {
            appendMessage('assistant', '抱歉，我遇到了一些问题。请检查你的 API Key 和网络连接。');
        }
    }
}

// 添加消息到聊天容器
function appendMessage(role, content, isStreaming = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = role === 'user' ? '👤' : '🤖';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.textContent = content || (isStreaming ? '' : '...');

    const time = document.createElement('div');
    time.className = 'message-time';
    time.textContent = new Date().toLocaleTimeString('zh-CN', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });

    contentDiv.appendChild(bubble);
    contentDiv.appendChild(time);

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);

    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;

    return bubble;
}

// 更新消息内容
function updateMessageContent(element, content) {
    element.textContent = content;
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// 清空对话
function handleClearChat() {
    if (confirm('确定要清空所有对话吗？')) {
        conversationHistory = [];
        saveConversationHistory();
        
        chatContainer.innerHTML = `
            <div class="welcome-message">
                <div class="welcome-icon">👋</div>
                <h2>欢迎使用 DeepSeek AI 助手</h2>
                <p>我可以帮助你回答问题、编写代码、创作内容等</p>
                <div class="suggestion-chips">
                    <button class="chip" data-prompt="介绍一下你自己">介绍一下你自己</button>
                    <button class="chip" data-prompt="用 Python 写一个快速排序">写一个快速排序</button>
                    <button class="chip" data-prompt="解释一下什么是机器学习">什么是机器学习？</button>
                </div>
            </div>
        `;

        // 重新绑定快捷提示事件
        document.querySelectorAll('.chip').forEach(chip => {
            chip.addEventListener('click', (e) => {
                const prompt = e.target.dataset.prompt;
                userInput.value = prompt;
                handleSendMessage();
            });
        });

        showToast('对话已清空', 'success');
    }
}

// 设置状态指示器
function setStatus(text, state) {
    statusIndicator.textContent = text;
    const indicator = statusIndicator.parentElement.querySelector('.status-indicator::before');
    
    if (state === 'thinking') {
        statusIndicator.style.color = 'var(--warning)';
    } else if (state === 'ready') {
        statusIndicator.style.color = 'var(--success)';
    } else {
        statusIndicator.style.color = 'var(--text-secondary)';
    }
}

// 显示提示消息
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'error' ? 'var(--error)' : type === 'success' ? 'var(--success)' : 'var(--primary-color)'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

