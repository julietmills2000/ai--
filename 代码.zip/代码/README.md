# DeepSeek API 调用示例

这是一个使用 Python 调用 DeepSeek API 的简单示例代码。

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 获取 API Key

访问 [DeepSeek 开放平台](https://platform.deepseek.com/) 注册并获取你的 API Key。

### 3. 配置 API Key

打开 `deepseek_api_example.py` 文件，将以下行：

```python
API_KEY = "your_deepseek_api_key_here"
```

替换为你的实际 API Key：

```python
API_KEY = "sk-xxxxxxxxxxxxxxxxxxxxxxxx"
```

### 4. 运行示例

```bash
python deepseek_api_example.py
```

## 功能说明

脚本包含以下功能示例：

- **基本对话**: 单次问答交互
- **多轮对话**: 保持上下文的连续对话
- **流式输出**: 实时显示 AI 回复（类似 ChatGPT 的打字效果）
- **代码生成**: 使用 AI 生成代码

## API 参数说明

### `call_deepseek_chat()` 参数

- `messages`: 对话消息列表，每条消息包含 `role` 和 `content`
  - `role`: 可以是 `"user"`, `"assistant"`, 或 `"system"`
  - `content`: 消息内容
- `model`: 模型名称，默认 `"deepseek-chat"`
- `temperature`: 控制输出随机性 (0-2)，越高越随机
- `max_tokens`: 最大生成的 token 数量

## 使用示例

### 简单问答

```python
messages = [
    {"role": "user", "content": "你好，请介绍一下你自己"}
]
result = call_deepseek_chat(messages)
print(result['choices'][0]['message']['content'])
```

### 多轮对话

```python
messages = [
    {"role": "user", "content": "什么是人工智能?"},
    {"role": "assistant", "content": "人工智能是..."},
    {"role": "user", "content": "能举个例子吗?"}
]
result = call_deepseek_chat(messages)
```

### 流式输出

```python
messages = [
    {"role": "user", "content": "写一首诗"}
]
call_deepseek_streaming(messages)
```

## 注意事项

1. 请妥善保管你的 API Key，不要泄露或提交到公共代码仓库
2. API 调用会消耗你的配额，请注意使用量
3. 建议使用环境变量来存储 API Key，而不是硬编码在代码中

## 使用环境变量（推荐）

在代码中使用环境变量：

```python
import os
API_KEY = os.getenv("DEEPSEEK_API_KEY")
```

在命令行中设置：

```bash
# Windows (PowerShell)
$env:DEEPSEEK_API_KEY="your_api_key_here"

# Windows (CMD)
set DEEPSEEK_API_KEY=your_api_key_here

# Linux/Mac
export DEEPSEEK_API_KEY="your_api_key_here"
```

## 更多资源

- [DeepSeek API 文档](https://platform.deepseek.com/api-docs/)
- [DeepSeek 开放平台](https://platform.deepseek.com/)


