// DeepSeek API 配置
const API_BASE_URL = 'https://api.deepseek.com/v1';
const API_KEY = 'sk-c1417a5dcd404ab4904982e9b3a44f87';

// 应用状态
let appState = {
    userInfo: {},
    category: '',
    version: '',
    currentQuestionIndex: 0,
    answers: []
};

// 问题库
const questions = {
    research: {
        detailed: [
            {
                question: '你目前的学习/研究状态如何？',
                options: ['进展顺利，有条不紊', '偶尔遇到困难，但能克服', '经常感到迷茫和困惑', '输入更多想法...']
            },
            {
                question: '你每天用于学习/研究的时间大约是？',
                options: ['少于4小时', '4-6小时', '6-8小时以上', '输入更多想法...']
            },
            {
                question: '你认为自己的学习效率如何？',
                options: ['非常高效', '一般水平', '效率较低', '输入更多想法...']
            },
            {
                question: '面对学术压力，你通常会？',
                options: ['主动寻求帮助', '独自解决', '感到焦虑但不知所措', '输入更多想法...']
            },
            {
                question: '你和导师/老师的沟通频率如何？',
                options: ['经常沟通', '偶尔交流', '很少沟通', '输入更多想法...']
            },
            {
                question: '你是否有明确的学术目标？',
                options: ['非常明确', '基本明确', '比较模糊', '输入更多想法...']
            },
            {
                question: '你觉得自己的专业选择是？',
                options: ['完全符合兴趣', '还算满意', '不太满意', '输入更多想法...']
            },
            {
                question: '遇到研究难题时，你的第一反应是？',
                options: ['查阅文献资料', '请教他人', '暂时放弃', '输入更多想法...']
            },
            {
                question: '你对未来的职业规划是？',
                options: ['非常清晰', '有大致方向', '完全不确定', '输入更多想法...']
            },
            {
                question: '你认为目前最大的困扰是什么？',
                options: ['时间管理', '知识储备不足', '缺乏动力', '输入更多想法...']
            }
        ],
        quick: [
            {
                question: '你目前的学习状态如何？',
                options: ['非常好', '一般', '不太好', '其他']
            },
            {
                question: '你认为最大的学习障碍是什么？',
                options: ['时间不够', '缺乏动力', '方法不对', '其他']
            },
            {
                question: '你希望在哪方面得到帮助？',
                options: ['时间管理', '学习方法', '心态调整', '其他']
            }
        ]
    },
    emotion: {
        detailed: [
            {
                question: '你如何描述你当前的人际关系？',
                options: ['和谐融洽', '基本稳定', '偶有矛盾', '输入更多想法...']
            },
            {
                question: '你是否经常感到孤独？',
                options: ['很少', '偶尔', '经常', '输入更多想法...']
            },
            {
                question: '在社交场合，你通常？',
                options: ['主动交流', '被动参与', '感到不自在', '输入更多想法...']
            },
            {
                question: '你对目前的情感状态满意吗？',
                options: ['非常满意', '还可以', '不太满意', '输入更多想法...']
            },
            {
                question: '遇到情感问题时，你会？',
                options: ['与朋友倾诉', '独自消化', '寻求专业帮助', '输入更多想法...']
            },
            {
                question: '你觉得自己的情绪管理能力如何？',
                options: ['很好', '一般', '需要提升', '输入更多想法...']
            },
            {
                question: '你是否有亲密的朋友或伴侣？',
                options: ['有，关系很好', '有，但不够亲密', '没有', '输入更多想法...']
            },
            {
                question: '你对建立新关系的态度是？',
                options: ['积极主动', '顺其自然', '比较抗拒', '输入更多想法...']
            },
            {
                question: '你认为自己擅长表达情感吗？',
                options: ['很擅长', '一般', '不太擅长', '输入更多想法...']
            },
            {
                question: '目前最困扰你的情感问题是？',
                options: ['缺乏理解', '难以信任他人', '害怕被拒绝', '输入更多想法...']
            }
        ],
        quick: [
            {
                question: '你的人际关系状态如何？',
                options: ['很好', '一般', '不太好', '其他']
            },
            {
                question: '你是否经常感到孤独？',
                options: ['很少', '偶尔', '经常', '其他']
            },
            {
                question: '你希望在情感方面得到什么帮助？',
                options: ['交友技巧', '情绪管理', '自我认知', '其他']
            }
        ]
    },
    hobby: {
        detailed: [
            {
                question: '你有明确的兴趣爱好吗？',
                options: ['有很多', '有一些', '没有明确的', '输入更多想法...']
            },
            {
                question: '你每周用于兴趣爱好的时间是？',
                options: ['5小时以上', '2-5小时', '少于2小时', '输入更多想法...']
            },
            {
                question: '你觉得自己的生活是否平衡？',
                options: ['非常平衡', '基本平衡', '失衡严重', '输入更多想法...']
            },
            {
                question: '你对探索新事物的态度是？',
                options: ['非常积极', '看情况', '比较保守', '输入更多想法...']
            },
            {
                question: '你的兴趣爱好是？',
                options: ['运动健身类', '艺术创作类', '学习成长类', '输入更多想法...']
            },
            {
                question: '你是否有长期坚持的爱好？',
                options: ['有，坚持多年', '有，但断断续续', '没有', '输入更多想法...']
            },
            {
                question: '阻碍你发展爱好的主要因素是？',
                options: ['时间不够', '缺乏资源', '没有动力', '输入更多想法...']
            },
            {
                question: '你希望培养什么类型的新爱好？',
                options: ['社交型', '个人成长型', '放松娱乐型', '输入更多想法...']
            },
            {
                question: '你的生活规划是否包括兴趣发展？',
                options: ['重点考虑', '有所考虑', '未曾考虑', '输入更多想法...']
            },
            {
                question: '你希望通过兴趣爱好获得什么？',
                options: ['放松心情', '提升技能', '社交机会', '输入更多想法...']
            }
        ],
        quick: [
            {
                question: '你是否有明确的兴趣爱好？',
                options: ['有很多', '有一些', '没有', '其他']
            },
            {
                question: '阻碍你发展爱好的主要原因是？',
                options: ['时间不够', '不知道选什么', '缺乏动力', '其他']
            },
            {
                question: '你希望在兴趣爱好方面得到什么建议？',
                options: ['如何选择', '如何坚持', '时间安排', '其他']
            }
        ]
    },
    health: {
        detailed: [
            {
                question: '你的睡眠质量如何？',
                options: ['很好', '一般', '较差', '输入更多想法...']
            },
            {
                question: '你每周的运动频率是？',
                options: ['3次以上', '1-2次', '几乎不运动', '输入更多想法...']
            },
            {
                question: '你的饮食习惯如何？',
                options: ['规律健康', '基本正常', '不太规律', '输入更多想法...']
            },
            {
                question: '你是否经常感到疲劳？',
                options: ['很少', '偶尔', '经常', '输入更多想法...']
            },
            {
                question: '你对自己的身体状况满意吗？',
                options: ['很满意', '还可以', '不满意', '输入更多想法...']
            },
            {
                question: '你是否有定期体检的习惯？',
                options: ['有，每年都检', '偶尔检查', '从不体检', '输入更多想法...']
            },
            {
                question: '你的压力水平如何？',
                options: ['压力小', '压力适中', '压力很大', '输入更多想法...']
            },
            {
                question: '你有什么缓解压力的方法？',
                options: ['运动', '冥想/放松', '社交', '输入更多想法...']
            },
            {
                question: '你对心理健康的关注程度是？',
                options: ['非常关注', '有所关注', '不太关注', '输入更多想法...']
            },
            {
                question: '你希望在健康方面重点改善什么？',
                options: ['睡眠质量', '运动习惯', '饮食结构', '输入更多想法...']
            }
        ],
        quick: [
            {
                question: '你的整体健康状态如何？',
                options: ['很好', '一般', '不太好', '其他']
            },
            {
                question: '你认为最需要改善的健康问题是？',
                options: ['睡眠', '运动', '饮食', '其他']
            },
            {
                question: '你希望得到哪方面的健康建议？',
                options: ['作息调整', '运动计划', '压力管理', '其他']
            }
        ]
    }
};

// DOM 元素
const views = {
    login: document.getElementById('loginView'),
    category: document.getElementById('categoryView'),
    version: document.getElementById('versionView'),
    question: document.getElementById('questionView'),
    result: document.getElementById('resultView')
};

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    loadUserData();
});

// 设置事件监听器
function setupEventListeners() {
    // 1. 登录表单
    document.getElementById('loginForm').addEventListener('submit', handleLogin);

    // 2. 分类选择
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', (e) => {
            const category = e.currentTarget.dataset.category;
            handleCategorySelect(category);
        });
    });

    // 3. 版本选择
    document.querySelectorAll('.version-card').forEach(card => {
        card.addEventListener('click', (e) => {
            const version = e.currentTarget.dataset.version;
            handleVersionSelect(version);
        });
    });

    // 4. 自定义输入提交
    document.getElementById('submitCustomInput').addEventListener('click', handleCustomInput);

    // 5. 重新开始按钮
    document.getElementById('restartBtn').addEventListener('click', restartApp);

    // 6. 下载报告按钮
    document.getElementById('downloadBtn').addEventListener('click', downloadReport);
}

// 加载用户数据
function loadUserData() {
    const savedData = localStorage.getItem('userAppState');
    if (savedData) {
        appState = JSON.parse(savedData);
        if (appState.userInfo && appState.userInfo.age) {
            // 如果已有用户信息，跳转到分类选择页
            showView('category');
        }
    }
}

// 保存应用状态
function saveAppState() {
    localStorage.setItem('userAppState', JSON.stringify(appState));
}

// 视图切换
function showView(viewName) {
    Object.keys(views).forEach(key => {
        views[key].classList.remove('active');
    });
    views[viewName].classList.add('active');
}

// ===== 1. 处理登录 =====
function handleLogin(e) {
    e.preventDefault();
    
    appState.userInfo = {
        age: document.getElementById('age').value,
        gender: document.getElementById('gender').value,
        address: document.getElementById('address').value,
        occupation: document.getElementById('occupation').value
    };

    saveAppState();
    showView('category');
    showToast('信息已保存', 'success');
}

// ===== 2. 处理分类选择 =====
function handleCategorySelect(category) {
    appState.category = category;
    appState.currentQuestionIndex = 0;
    appState.answers = [];
    saveAppState();
    showView('version');
}

// ===== 3. 处理版本选择 =====
function handleVersionSelect(version) {
    appState.version = version;
    saveAppState();
    startQuestionnaire();
}

// ===== 4. 开始问卷调查 =====
function startQuestionnaire() {
    showView('question');
    showQuestion(0);
}

// 显示问题
function showQuestion(index) {
    const questionSet = questions[appState.category][appState.version];
    const totalQuestions = questionSet.length;
    
    if (index >= totalQuestions) {
        // 所有问题已回答完毕
        generateResult();
        return;
    }

    const currentQuestion = questionSet[index];
    appState.currentQuestionIndex = index;

    // 更新进度条
    const progress = ((index + 1) / totalQuestions) * 100;
    document.getElementById('progressFill').style.width = `${progress}%`;
    document.getElementById('progressText').textContent = `${index + 1}/${totalQuestions}`;

    // 更新问题标题
    document.getElementById('questionTitle').textContent = currentQuestion.question;

    // 生成选项
    const optionsContainer = document.getElementById('questionOptions');
    optionsContainer.innerHTML = '';

    currentQuestion.options.forEach((option, optionIndex) => {
        const button = document.createElement('button');
        button.className = 'option-btn';
        button.textContent = option;
        
        // 最后一个选项是自定义输入
        if (appState.version === 'detailed' && optionIndex === currentQuestion.options.length - 1) {
            button.addEventListener('click', () => {
                showCustomInput();
            });
        } else {
            button.addEventListener('click', () => {
                handleAnswerSelect(option, currentQuestion.question);
            });
        }

        optionsContainer.appendChild(button);
    });

    // 隐藏自定义输入区域
    document.getElementById('customInputArea').classList.add('hidden');
    document.getElementById('customInput').value = '';
}

// 显示自定义输入框
function showCustomInput() {
    const customInputArea = document.getElementById('customInputArea');
    customInputArea.classList.remove('hidden');
    document.getElementById('customInput').focus();
}

// 处理自定义输入
function handleCustomInput() {
    const customText = document.getElementById('customInput').value.trim();
    if (!customText) {
        showToast('请输入你的想法', 'warning');
        return;
    }

    const questionSet = questions[appState.category][appState.version];
    const currentQuestion = questionSet[appState.currentQuestionIndex];
    
    handleAnswerSelect(customText, currentQuestion.question);
}

// 处理答案选择
function handleAnswerSelect(answer, question) {
    appState.answers.push({
        question: question,
        answer: answer
    });

    saveAppState();

    // 显示下一个问题
    setTimeout(() => {
        showQuestion(appState.currentQuestionIndex + 1);
    }, 300);
}

// ===== 5. 生成结果 =====
async function generateResult() {
    showView('result');
    
    // 显示加载动画
    document.getElementById('loadingSpinner').classList.remove('hidden');
    document.getElementById('resultContent').classList.add('hidden');

    // 显示用户信息
    displayUserInfo();

    // 调用 AI 生成建议
    await callAIForSuggestion();
}

// 显示用户信息摘要
function displayUserInfo() {
    const container = document.getElementById('userInfoSummary');
    container.innerHTML = `
        <div class="info-item">
            <label>年龄</label>
            <span>${appState.userInfo.age}岁</span>
        </div>
        <div class="info-item">
            <label>性别</label>
            <span>${appState.userInfo.gender}</span>
        </div>
        <div class="info-item">
            <label>地址</label>
            <span>${appState.userInfo.address}</span>
        </div>
        <div class="info-item">
            <label>职业</label>
            <span>${appState.userInfo.occupation}</span>
        </div>
    `;
}

// 调用 AI 生成建议
async function callAIForSuggestion() {
    try {
        // 构建提示词
        const prompt = buildPrompt();

        const response = await fetch(`${API_BASE_URL}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify({
                model: 'deepseek-chat',
                messages: [
                    {
                        role: 'system',
                        content: '你是一位专业的心理健康顾问和生活规划师。请根据用户提供的信息，给出专业、温暖、具有可操作性的建议。'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.7,
                max_tokens: 2000,
                stream: false
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || '请求失败');
        }

        const data = await response.json();
        const suggestion = data.choices[0].message.content;

        // 显示结果
        document.getElementById('loadingSpinner').classList.add('hidden');
        document.getElementById('resultContent').classList.remove('hidden');
        document.getElementById('aiSuggestion').textContent = suggestion;

    } catch (error) {
        console.error('AI 调用失败:', error);
        document.getElementById('loadingSpinner').classList.add('hidden');
        document.getElementById('resultContent').classList.remove('hidden');
        document.getElementById('aiSuggestion').textContent = 
            '抱歉，生成建议时遇到了问题。请检查网络连接或稍后重试。\n\n错误信息：' + error.message;
        showToast(`错误: ${error.message}`, 'error');
    }
}

// 构建提示词
function buildPrompt() {
    const categoryNames = {
        research: '学业研究',
        emotion: '情感关系',
        hobby: '兴趣爱好',
        health: '健康管理'
    };

    const versionNames = {
        detailed: '详细评估',
        quick: '快速评估'
    };

    let prompt = `用户基本信息：
- 年龄：${appState.userInfo.age}岁
- 性别：${appState.userInfo.gender}
- 地址：${appState.userInfo.address}
- 职业：${appState.userInfo.occupation}

咨询领域：${categoryNames[appState.category]}
评估模式：${versionNames[appState.version]}

问题和回答：\n`;

    appState.answers.forEach((item, index) => {
        prompt += `${index + 1}. ${item.question}\n   回答：${item.answer}\n\n`;
    });

    prompt += `\n请根据以上信息，提供一份详细的分析和建议。包括：
1. 当前状况分析（结合用户的基本信息和回答）
2. 存在的问题或困扰
3. 具体的改善建议（至少3-5条，每条要具体可行）
4. 鼓励和支持的话语

请用温暖、专业、易懂的语言撰写，让用户感受到关心和支持。`;

    return prompt;
}

// 重新开始
function restartApp() {
    if (confirm('确定要重新开始吗？当前的数据将被清除。')) {
        appState = {
            userInfo: {},
            category: '',
            version: '',
            currentQuestionIndex: 0,
            answers: []
        };
        saveAppState();
        showView('login');
        document.getElementById('loginForm').reset();
        showToast('已重置，请重新填写信息', 'success');
    }
}

// 下载报告
function downloadReport() {
    const categoryNames = {
        research: '学业研究',
        emotion: '情感关系',
        hobby: '兴趣爱好',
        health: '健康管理'
    };

    let reportText = `AI 心理健康分析报告\n`;
    reportText += `生成时间：${new Date().toLocaleString('zh-CN')}\n\n`;
    reportText += `=================================\n\n`;
    reportText += `基本信息：\n`;
    reportText += `年龄：${appState.userInfo.age}岁\n`;
    reportText += `性别：${appState.userInfo.gender}\n`;
    reportText += `地址：${appState.userInfo.address}\n`;
    reportText += `职业：${appState.userInfo.occupation}\n\n`;
    reportText += `咨询领域：${categoryNames[appState.category]}\n\n`;
    reportText += `=================================\n\n`;
    reportText += `问题和回答：\n\n`;

    appState.answers.forEach((item, index) => {
        reportText += `${index + 1}. ${item.question}\n`;
        reportText += `   ${item.answer}\n\n`;
    });

    reportText += `=================================\n\n`;
    reportText += `AI 建议：\n\n`;
    reportText += document.getElementById('aiSuggestion').textContent;

    // 创建下载
    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AI分析报告_${new Date().getTime()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('报告已下载', 'success');
}

// 显示提示消息
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#6366f1'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        animation: slideIn 0.3s ease;
        max-width: 300px;
    `;
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

